<div id="logo-banner" class="lateral-gap">
  <a href="https://www.zerozero.pt/" target="_blank">
    <image src="./img/logo_zerozero.png" alt="ZeroZero Logo">
  </a>
</div>

<div id="page-header" class="lateral-gap">
  <div id="page-header-content" class="vertical-gap">
    <p class="title"><?php echo $h1 ?></p>
    <p class="text"><?php echo $description ?></p>
  </div>
</div>